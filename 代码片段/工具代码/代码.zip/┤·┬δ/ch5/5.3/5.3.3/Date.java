public class Date extends java.util.Date {

    // Ĭ�ϵ���������һ������
    private static final int DEFAULT_CAPACITY = 10;

    /**
     * ����
     */
    public int size;
    
    int longName1 = 0, longName2 = 0, longName3 = 0, longName4 = 0, longName5 = 0;
    
    boolean boolName1 = true;

    public String getString() {

        int year = super.getYear() + 1900; // �������
        int month = super.getMonth() + 1; /* �����·� */
        int day = super.getDate();
        // ...

        if ((longName1 == longName2)
                || (longName3 == longName4) && (longName3 > longName4) 
                && (longName2 > longName5)) {

        }
                 
        return null;
    }
}