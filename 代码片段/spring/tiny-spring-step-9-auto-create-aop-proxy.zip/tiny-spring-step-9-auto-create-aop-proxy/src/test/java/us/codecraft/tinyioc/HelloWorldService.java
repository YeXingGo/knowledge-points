package us.codecraft.tinyioc;

/**
 * @author yihua.huang@dianping.com
 */
public interface HelloWorldService {

    void helloWorld();
}
