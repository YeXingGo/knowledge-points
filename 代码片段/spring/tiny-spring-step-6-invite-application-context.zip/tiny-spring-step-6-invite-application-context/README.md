tiny-spring
=======

A tiny IoC container refer to Spring.
