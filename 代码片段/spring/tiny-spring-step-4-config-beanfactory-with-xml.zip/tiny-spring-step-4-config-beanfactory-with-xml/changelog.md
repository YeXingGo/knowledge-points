tiny-IoC
=====

步骤：

## 1.step1-最基本的容器
*step-1-container-register-and-get*

单纯的map，有get和put bean的功能


## 2.step2-将bean创建放入工厂
*step-2-abstract-beanfactory-and-do-bean-initilizing-in-it*

1. 抽象beanfactory
2. 将bean初始化放入beanfactory
	
## 3.step3-为bean注入属性
*step-3-inject-bean-with-property*

## 4.step4-读取xml配置来初始化bean
*step-4-config-beanfactory-with-xml*